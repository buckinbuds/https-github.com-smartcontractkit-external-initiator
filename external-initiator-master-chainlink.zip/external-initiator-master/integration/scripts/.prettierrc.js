module.exports = {
  semi: false,
  singleQuote: true,
  printWidth: 80,
  endOfLine: 'auto',
  trailingComma: 'all',
}
